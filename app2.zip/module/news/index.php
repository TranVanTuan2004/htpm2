<?php 
	$ac = getIndex('ac','home');

	if($ac == 'dosendmail')
		include 'sendmail.php';
 ?>
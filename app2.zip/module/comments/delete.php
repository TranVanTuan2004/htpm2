<?php
    echo "This is delete Comment";
?>